package com.esprit.spring.entites;

public enum CategorieClient {FIDELE,ORDINAIRE,PREMIUM}
