package com.esprit.spring.entites;

public enum CategorieProduit {
	ELECTOMENAGER,ALIMENTAIRE,QUINCAILLERIE

}
