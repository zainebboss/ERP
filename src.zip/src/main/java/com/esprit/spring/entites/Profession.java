package com.esprit.spring.entites;

public enum Profession {
	DOCTEUR,INGENIEUR,ETUDIANT,COMMERCIAL,CADRE,AUTRE

}
